﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace dotp2p3
{
    public partial class Form1 : Form
    {
        double num1, res,mr;
        string  operation;
        core_calculator c = new core_calculator();
        public Form1()
        {
            InitializeComponent();
            mr = 0;
        }
        private void on_click_num(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            
            
            if (button.Text != "." || !textBox1.Text.Contains("."))
            {
                textBox1.Text = textBox1.Text + button.Text;
            }

        }

        private void button19_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            label1.Text = "";
            num1 = res = 0;
        }

        private void finalRes(object sender, EventArgs e)
        {

            switch (operation)
            {
                case "+":
                    if (textBox1.Text == "")
                    {
                        res = Convert.ToDouble(label1.Text);
                    }
                    else
                    {
                        num1 = Convert.ToDouble(textBox1.Text);
                        res = c.add(num1, res);
                    }
                    break;
                case "-":

                    if (textBox1.Text == "")
                    {
                        res = Convert.ToDouble(label1.Text);
                    }
                    else
                    {
                        num1 = Convert.ToDouble(textBox1.Text);
                        res = c.minus(num1, res);
                    }
                    
                    break;
                case "*":
                    if (textBox1.Text == "")
                    {
                        res = Convert.ToDouble(label1.Text);
                    }
                    else
                    {
                        num1 = Convert.ToDouble(textBox1.Text);
                        res = c.mul(num1, res);
                    }
                    
                    break;
                case "/":
                    if (textBox1.Text == "")
                    {
                        res = Convert.ToDouble(label1.Text);
                    }
                    else
                    {
                        num1 = Convert.ToDouble(textBox1.Text);
                        res = c.div(num1, res);
                    }
                    
                    break;
            }
            label1.Text = "";
            textBox1.Text = Convert.ToString(res);
            num1 = res = 0;
        }
        private void button18_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }
        private void memory_recall(object sender, EventArgs e)
        {
            Button mrbtn = (Button)sender;
            if(mrbtn.Text=="M+")
            {
                mr = mr + Convert.ToDouble( textBox1.Text);
                textBox1.Clear();
            }
            else if (mrbtn.Text == "M-")
            {
                mr = mr - Convert.ToDouble(textBox1.Text);
                textBox1.Clear();
            }
            else if (mrbtn.Text == "MR")
            {
                textBox1.Text = mr.ToString();
            }
            else if (mrbtn.Text == "MC")
            {
                mr = 0;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operation = button.Text;
            if (label1.Text == "")
            {
                try
                {
                    label1.Text = textBox1.Text;
                    res = Convert.ToDouble(label1.Text);
                    textBox1.Text = "";
                }
                catch{}
            }
            else
            {
                if (button.Text == "+")
                {
                    try
                    {
                        num1 = Convert.ToDouble(textBox1.Text);
                        res = c.add(num1, res);
                        label1.Text = res.ToString();
                        textBox1.Text = "";
                    }
                    catch { }

                }
                else if (button.Text == "-")
                {
                    try
                    {
                        num1 = Convert.ToDouble(textBox1.Text);
                        res = c.minus(num1, res);
                        label1.Text = res.ToString();
                        textBox1.Text = "";
                    }
                    catch { }
                }
                else if (button.Text == "*")
                {
                    try { num1 = Convert.ToDouble(textBox1.Text);
                        res = c.mul(num1, res);
                        label1.Text = res.ToString();
                        textBox1.Text = "";
                    }
                    catch { }
                }
                else if (button.Text == "/")
                {
                    try
                    {
                        num1 = Convert.ToDouble(textBox1.Text);
                        res = c.div(num1, res);
                        label1.Text = res.ToString();
                        textBox1.Text = "";
                    }
                    catch { }
                }
            }
        }
    }
}