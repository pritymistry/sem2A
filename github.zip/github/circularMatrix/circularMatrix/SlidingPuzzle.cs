﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace circularMatrix
{
    public partial class SlidingPuzzle : Form
    {
        Button[] b = new Button[12];
        List<int> randomList = new List<int>();

       
        public SlidingPuzzle()
        {
            InitializeComponent();
            createbutton();

        }

        void createbutton()
        {

            regenerate();
            int x = 100;
            int y = 100;
            for (int i = 0; i < b.Length; i++)
            {
                if (i == b.Length - 1)
                {
                    b[i] = new Button
                    {
                        Text = "",
                        Visible = true,
                        Tag = i + "",
                    };
                }
                else
                {
                    b[i] = new Button
                    {
                        Text = randomList[i] + "",
                        Visible = true,
                        Tag = i + "",
                    };
                }
                b[i].Click += ButtonDynamic_Click;
                b[i].Location = new Point(x, y);
                b[i].Size = new Size(50, 50);

                x = x + 50;
                if ((i + 1) % 4 == 0)
                {
                    y = y + 50;
                    x = 100;
                }

                Controls.Add(b[i]);
            }
        }
        private void ButtonDynamic_Click(object sender, EventArgs e)
        {
            Button bt = (Button)sender;
            int pos = Int16.Parse(bt.Tag.ToString());
            if (pos - 1 < b.Length && pos - 1 >= 0 && b[pos - 1].Text == "")
            {
                b[pos - 1].Text = bt.Text;
                bt.Text = "";
            }
            if (pos + 1 < b.Length && b[pos + 1].Text == "")
            {
                b[pos + 1].Text = bt.Text;
                bt.Text = "";
            }
            if (pos - 4 >= 0 && b[pos - 4].Text == "")
            {
                b[pos - 4].Text = bt.Text;
                bt.Text = "";
            }
            if (pos + 4 < b.Length && b[pos + 4].Text == "")
            {
                b[pos + 4].Text = bt.Text;
                bt.Text = "";
            }
            checkcomplete();
            //
            //MessageBox.Show("Click event handler!", "Message Box", MessageBoxButtons.OK);
        }
        void checkcomplete()
        {
            bool flag = true;
            for (int i = 0; i < b.Length - 1; i++)
            {
                if (b[i].Text == (i + 1).ToString())
                {
                    continue;
                }
                else
                {
                    flag = false;
                    break;
                }
            }
            if (flag == true)

            {
                MessageBox.Show("Game Over ,Wins");
                regenerate();
            }
        }
        void regenerate()
        {
            randomList.Clear();
            Random a = new Random();
            int MyNumber = 0;
            int cnt = 1;
            while (cnt < 12)
            {
                MyNumber = a.Next(1, 12); //cnt; 
                if (!randomList.Contains(MyNumber))
                {
                    randomList.Add(MyNumber);
                    cnt++;
                }
            }
        }

        private void SlidingPuzzle_Load(object sender, EventArgs e)
        {

        }
    }
}
