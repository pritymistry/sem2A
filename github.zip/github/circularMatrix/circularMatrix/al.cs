﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace circularMatrix
{
    public partial class al : Form
    {
        public al()
        {
            InitializeComponent();
        }
        ArrayList list = new ArrayList();
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void ArrayList_Load(object sender, EventArgs e)
        {

        }

        private void add_Click(object sender, EventArgs e)
        {
            String str = Convert.ToString(textBox1.Text);
            list.Add(str);
            listBox1.Items.Clear();
            textBox1.Text = "";
            foreach (string element in list)
            {
                listBox1.Items.Add(element);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            
        }

        private void Add(string v)
        {
            throw new NotImplementedException();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Insert_Click(object sender, EventArgs e)
        {
            String str = Convert.ToString(textBox2.Text);
            int index = Convert.ToInt32(textBox4.Text);
            list.Insert(index,str);
            textBox2.Text = "";
            textBox4.Text = "";
            listBox1.Items.Clear();
            foreach (string element in list)
            {
                listBox1.Items.Add(element);
            }
        }

        private void remove_Click(object sender, EventArgs e)
        {
            String str = Convert.ToString(textBox3.Text);
            list.Remove(str);
            listBox1.Items.Clear();
            textBox3.Text = "";
            foreach (string element in list)
            {
                listBox1.Items.Add(element);
            }
        }
    }
}
