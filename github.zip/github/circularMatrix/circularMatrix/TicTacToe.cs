﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace circularMatrix
{
    public partial class TicTacToe : Form
    {
        Button[] b = new Button[9];
        bool turn=true;
        double cnt = 0;
        public TicTacToe()
        {
            InitializeComponent();
        }

        private void TicTacToe_Load(object sender, EventArgs e)
        {

            for (int i=0;i<9;i++)
            {
                b[i] = new Button();
                b[i].Width = 100;
                b[i].Height = 100;
                b[i].Click += new EventHandler(buttonclick);
                flowLayoutPanel1.Controls.Add(b[i]);
            }
        }
        private void buttonclick(object sender, EventArgs e)
        {
            Button bt=(Button)sender;
            if (turn==true)
            {
                bt.Text = "X";
            }
            else
            {
                bt.Text = "0";
            }
            turn = !turn;
            bt.Enabled = false;
            cnt++;
            checkWin();
            if (cnt==9)
            {
                MessageBox.Show("Match Draw");
            }
        }
        private void reset()
        {
            for (int i=0;i<9;i++)
            {
                b[i].Enabled = true;
                b[i].Text = "";
            }
            turn = true;
            cnt = 0;
        }
        private void checkWin()
        {
            if (b[0].Text== b[1].Text && b[1].Text == b[2].Text && b[0].Text!="")
            {
                MessageBox.Show(b[0].Text+" is a WINNER.");
                reset();
            }
            if (b[3].Text == b[4].Text && b[4].Text == b[5].Text && b[3].Text != "")
            {
                MessageBox.Show(b[3].Text + " is a WINNER.");
                reset();
            }
            if (b[6].Text == b[7].Text && b[7].Text == b[8].Text && b[6].Text != "")
            {
                MessageBox.Show(b[6].Text + " is a WINNER.");
                reset();
            }
            if (b[0].Text == b[4].Text && b[4].Text == b[8].Text && b[0].Text != "")
            {
                MessageBox.Show(b[0].Text + " is a WINNER.");
                reset();
            }
            if (b[2].Text == b[4].Text && b[4].Text == b[6].Text && b[2].Text != "")
            {
                MessageBox.Show(b[2].Text + " is a WINNER.");
                reset();
            }
            if (b[0].Text == b[3].Text && b[3].Text == b[6].Text && b[0].Text != "")
            {
                MessageBox.Show(b[0].Text + " is a WINNER.");
                reset();
            }
            if (b[1].Text == b[4].Text && b[4].Text == b[7].Text && b[1].Text != "")
            {
                MessageBox.Show(b[1].Text + " is a WINNER.");
                reset();
            }
            if (b[2].Text == b[5].Text && b[5].Text == b[8].Text && b[2].Text != "")
            {
                MessageBox.Show(b[2].Text + " is a WINNER.");
                reset();
            }
        }
    }
}


/*
 Button[] btnArray = new Button[5]; // Create an array to store buttons

            for (int i = 0; i < btnArray.Length; i++) // Loop through the array
            {
                btnArray[i] = new Button(); // Create a new button
                btnArray[i].Text = "Button " + (i + 1); // Set the button text
                if (i >= 3)
                {
                    btnArray[i].Location = new Point(10, (i * 30) + 10); // Set the button position

                }
                else {
                    btnArray[i].Location = new Point(10, (i * 30) + 10);
                }
                this.Controls.Add(btnArray[i]); // Add the button to the form
            }
     */
