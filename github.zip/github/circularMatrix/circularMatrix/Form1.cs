﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace circularMatrix
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int size = Convert.ToInt32(textBox1.Text);
            int[,] matrix = new int[size, size];

            int rowStart = 0, colStart = 0, rowEnd = size - 1, colEnd = size - 1;
            int count = 1;

            while (rowStart <= rowEnd && colStart <= colEnd)
            {
                // Print the top row
                for (int i = colStart; i <= colEnd; i++)
                {
                    matrix[rowStart, i] = count++;
                }

                rowStart++;

                // Print the right column
                for (int i = rowStart; i <= rowEnd; i++)
                {
                    matrix[i, colEnd] = count++;
                }

                colEnd--;

                // Print the bottom row
                for (int i = colEnd; i >= colStart; i--)
                {
                    matrix[rowEnd, i] = count++;
                }

                rowEnd--;

                // Print the left column
                for (int i = rowEnd; i >= rowStart; i--)
                {
                    matrix[i, colStart] = count++;
                }

                colStart++;
            }

            // Display the matrix in the DataGridView
            dataGridView1.RowCount = size;
            dataGridView1.ColumnCount = size;
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = matrix[i, j];
                }
            }
        }
    }
}
    
