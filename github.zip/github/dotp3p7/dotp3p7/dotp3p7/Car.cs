﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotp3p7
{
    class Car
    {
        int price, launchyear;
        string name, modelname;
        public Car() { }
        public void setData(int price,int launchyear,string name,string modelname)
        {
            this.price = price;
            this.launchyear = launchyear;
            this.name = name;
            this.modelname = modelname;
        }
        public string getData()
        {
            return "Name:- " + name + "  ModelName:- " + modelname + "  Price:- "+price+"  Launch Year:- "+launchyear;
        }
    }
}
