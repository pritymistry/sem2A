﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dotp3p7
{
    public partial class Form1 : Form
    {
        Label namelbl, pricelbl, modlbl, yearlbl,displaylbl;
        TextBox nametxt, pricetxt, modtxt, yeartxt;
        Car c;
        ArrayList al = new ArrayList();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            namelbl = new Label();
            namelbl.Text = "Name:- ";
            namelbl.Top = 20;
            namelbl.Left = 20;
            Controls.Add(namelbl);
            nametxt = new TextBox();
            nametxt.Top = 20;
            nametxt.Name = "nametext";
            nametxt.Left = 130;
            Controls.Add(nametxt);


            pricelbl = new Label();
            pricelbl.Text = "Price:- ";
            pricelbl.Top = 20*3;
            pricelbl.Left = 20;
            Controls.Add(pricelbl);
             pricetxt = new TextBox();
            pricetxt.Top = 20 * 3;
            pricetxt.Name = "pricetext";
            pricetxt.Left = 130;
            Controls.Add(pricetxt);

            modlbl = new Label();
            modlbl.Text = "Model:- ";
            modlbl.Top = 20*5;
            modlbl.Left = 20;
            Controls.Add(modlbl);
             modtxt = new TextBox();
            modtxt.Top = 20*5;
            modtxt.Name = "modtext";
            modtxt.Left = 130;
            Controls.Add(modtxt);


            yearlbl = new Label();
            yearlbl.Text = "Year:- ";
            yearlbl.Top = 20*7;
            yearlbl.Left = 20;
            Controls.Add(yearlbl);
             yeartxt = new TextBox();
            yeartxt.Top = 20*7;
            yeartxt.Name = "yeartext";
            yeartxt.Left = 130;
            Controls.Add(yeartxt);


            Button insbtn = new Button();
            insbtn.Text = "Add";
            insbtn.Top = 50;
            insbtn.Left = 130 * 2;
            insbtn.Height = 100;
            Controls.Add(insbtn);

            Button disbtn = new Button();
            disbtn.Text = "Display";
            disbtn.Top = 50;
            disbtn.Left = (130 * 2)+100;
            disbtn.Font = new Font("Display",12);
            disbtn.Height = 100;
            Controls.Add(disbtn);


            displaylbl = new Label();
            displaylbl.Text = "";
            displaylbl.Name = "distext";
            displaylbl.Width = 1000;
            displaylbl.BackColor = System.Drawing.Color.Gray;
            displaylbl.Top = 20 * 9;
            displaylbl.Left = 20;
            displaylbl.Height = 1000;
            Controls.Add(displaylbl);

            EventHandler addeh = new EventHandler(addinto);
            insbtn.Click += addeh;
            
            EventHandler displayeh = new EventHandler(displayfrom);
            disbtn.Click += displayeh;
        }
        private void addinto(object sender, EventArgs e)
        {
            try
            {
                c = new Car();
                c.setData(Convert.ToInt32( pricetxt.Text),Convert.ToInt32( yeartxt.Text),nametxt.Text,modtxt.Text);
                al.Add(c);
            }
            catch { MessageBox.Show("Please enter data properly"); }
        }
        private void displayfrom(object sender, EventArgs e)
        {
            displaylbl.Text = "";
            foreach (Car obj in al)
            {
                
                displaylbl.Text = displaylbl.Text + obj.getData()+"\n";
            }
        }
    }
}